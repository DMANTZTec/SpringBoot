package com.dmantz.vamshi.commom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DmantzLearninSysytemApplicationTests {

	@Test
	void contextLoads() {
	}

}
