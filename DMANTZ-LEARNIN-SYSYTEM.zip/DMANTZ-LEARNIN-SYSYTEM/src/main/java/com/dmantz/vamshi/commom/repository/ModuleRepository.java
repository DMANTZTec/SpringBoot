package com.dmantz.vamshi.commom.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.dmantz.vamshi.commom.entity.Module;

public interface ModuleRepository extends JpaRepository<Module,Integer>
{

}
