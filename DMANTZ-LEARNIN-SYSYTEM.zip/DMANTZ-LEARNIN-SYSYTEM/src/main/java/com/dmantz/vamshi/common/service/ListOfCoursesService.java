package com.dmantz.vamshi.common.service;

import java.util.List;

import com.dmantz.vamshi.common.entity.Course;

public interface ListOfCoursesService {
	public List<Course> findAll();

}
