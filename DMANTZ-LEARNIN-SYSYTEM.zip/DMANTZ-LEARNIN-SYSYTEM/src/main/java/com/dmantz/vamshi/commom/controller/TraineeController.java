package com.dmantz.vamshi.commom.controller;
//@RestController
public class TraineeController {
	

}
