package com.dmantz.vamshi.commom.service;

public class ModuleServiceImpl implements ModuleService {

}
