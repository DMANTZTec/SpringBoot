package com.dmantz.vamshi.commom.entity;

public class Worklog {

}
