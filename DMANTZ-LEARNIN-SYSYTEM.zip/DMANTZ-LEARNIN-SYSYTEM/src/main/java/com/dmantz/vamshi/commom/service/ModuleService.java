package com.dmantz.vamshi.commom.service;

public interface ModuleService {

}
