package com.dmantz.vamshi.common.service;

public class TraineeServiceImpl implements TraineeService {

}
