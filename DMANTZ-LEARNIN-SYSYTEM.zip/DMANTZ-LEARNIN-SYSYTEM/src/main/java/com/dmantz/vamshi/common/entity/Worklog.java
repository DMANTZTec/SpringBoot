package com.dmantz.vamshi.common.entity;

public class Worklog {

}
