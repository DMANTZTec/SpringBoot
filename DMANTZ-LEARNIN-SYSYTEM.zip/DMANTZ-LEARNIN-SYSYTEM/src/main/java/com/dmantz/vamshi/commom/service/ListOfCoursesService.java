package com.dmantz.vamshi.commom.service;

import java.util.List;

import com.dmantz.vamshi.commom.entity.ListOfCourses;

public interface ListOfCoursesService {
	public List<ListOfCourses> findAll();

}
