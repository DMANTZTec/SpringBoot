package com.dmantz.vamshi.commom.service;

public class TraineeServiceImpl implements TraineeService {

}
