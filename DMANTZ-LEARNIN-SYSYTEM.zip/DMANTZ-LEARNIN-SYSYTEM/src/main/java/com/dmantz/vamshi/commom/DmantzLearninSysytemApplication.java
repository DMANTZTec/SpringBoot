package com.dmantz.vamshi.commom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DmantzLearninSysytemApplication {

	public static void main(String[] args) {
		SpringApplication.run(DmantzLearninSysytemApplication.class, args);
	}

}
